//Importing components
import './Styles/Style.css';
import Carousel from './Components/Carousel';
import AudioGesture from "./Components/AudioGesture";
import {useState} from "react";
import ActivityCard from "./Components/ActivityCard";
import {images, videos} from "./Assets/photos.js";

function Web() {
  //State for the categories selected. Culture as the default
  const [activeCategory, setActiveCategory] = useState("Culture");

  //Stores de cart items
  const [cart, setCart] = useState([]);
  //Opens and closes the cart menu (depending on the state)
  const [cartOpen, setCartOpen] = useState(false); 
  //Total number of items
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  //Total price of the cart
  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity,0);
  //Adds an activity to the cart
  const AddToCart = (activity) => {
    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.id === activity.id);
      if (existing) {
        // If exists, increase quantity
        return prevCart.map((item) =>
          item.id === activity.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      //If not, new item
      return [...prevCart, { ...activity, quantity: 1 }];
    });
  };
  //Removes an activity from the cart
  const removeFromCart = (id) => {
    setCart((prevCart) =>
      prevCart
        .map((item) => item.id === id ? { ...item, quantity: item.quantity - 1 } : item)
        //Only if the quantity of the item is bigger than 0
        .filter((item) => item.quantity > 0)
    );
  };
  //Increase quantity of an activity already in the cart
  const increaseQuantity = (id) => {
    setCart((prevCart) =>
      prevCart.map((item) =>
        item.id === id ? { ...item, quantity: item.quantity + 1 } : item
      )
    );
  };
  return (
    <div className="Web">
      <div className="title_wrapper">
        <div className="cart_icon" onClick={() => setCartOpen((prev) => !prev)}>
          <span className="cart_count">{cartCount}</span>
          <span className="cart_icon">🛒</span>
          {/* Cart menu */}
          {cartOpen && (
            <div className="cart_menu" onClick={(e) => e.stopPropagation()}>
              {cart.length === 0 && <p className="empty_cart">Cart is empty</p>}
              {cart.map((item) => (
                <div key={item.id} className="cart_item">
                  <span className="item_name">{item.name}</span>
                  <span className="item_quantity">x{item.quantity}</span>
                  <button onClick={(e) => {
                    {/* For stopping its closing when clicking */}
                    e.stopPropagation(); 
                    increaseQuantity(item.id);
                  }}> + </button>
                  <button onClick={(e) => {
                    {/* For stopping its closing when clicking */}
                    e.stopPropagation(); 
                    removeFromCart(item.id);
                  }}> - </button>
                  </div>
              ))}
              {/* Display total price */}
              {cart.length > 0 && (
                <div className="cart_total">
                  <span className="total_name">Total:</span>
                  <span className="total_price"> {totalPrice.toFixed(2)}$</span>
                </div>
              )}
            </div>
          )}
        </div>
        {/* Main page title */}
        <h1> VISIT TOKYO </h1>
        {/* Intro text box */}
        <div className="about_textbox">
          <h2>About Tokyo</h2>
          <p className="about_text">
            Tokyo, the capital of Japan, is a city where tradition meets the future, combining modern technology with ancient temples and cultural values.
            The city is full of bright lights, busy streets and delicious food, offering unique experiences at every corner. <br></br>
            Tokyo has also quiet places where visitors can feel the history and traditions of Japan.
            Whether you enjoy calm nature or fast-paced city life, Tokyo has something unforgettable for every traveler.
          </p>
        </div>
        {/* Carousel animation */}
        <div className="carousel-section">
          <Carousel
            baseWidth={500}
            autoplay={true}
            autoplayDelay={3000}
            pauseOnHover={true}
            loop={true}
            round={false}
          />
        </div>
      </div>

      {/* Nav bar */}
      <div className="categories">
        <span className={activeCategory === "Culture" && "active"} onClick={() => setActiveCategory("Culture")}>Culture</span>
        <span className={activeCategory === "Gastronomy" && "active"} onClick={() => setActiveCategory("Gastronomy")}>Gastronomy</span>
        <span className={activeCategory === "Nature" && "active"} onClick={() => setActiveCategory("Nature")}>Nature</span>
        <span className={activeCategory === "UrbanLife" && "active"} onClick={() => setActiveCategory("UrbanLife")}>Urban Life</span>
      </div>

      <div className="page">
        {/* Culture section */}
        {activeCategory === "Culture" && (
          <div>
            <h2>Culture in Tokyo</h2>
            <hr></hr>
            <p>
              <b>Tokyo is the main cultural city of Japan.</b> Japanese people may seem shy to the western people such as Americans, but the Japanese culture
              is unique to some other cultures in the world. <br></br> Japan has a lot of traditions and cultural values, but its culture can feel very strange and different to people from other countries.
              Any non-Japanese people aren't accepted to the Japanese culture, but the visitors have to be very careful to do some of the basic traditions that Japan offers. 
              These can be like bowing in front of someone before saying 'Hello' or 'Hi' in Japanese, if you fail to do this tradition, you will be considered <b>impolite to the Japanese culture.</b> <br></br>
              Some other basic traditions include, not wearing shoes inside homes, temples and other places and after purchasing something do not count the change, this is considered rude.   
              <b>Doing these basic traditions can lead to being accepted in the society of Japan.</b> <br></br>
              <br></br>
              Here are some of the most interesting cultural activities in Tokyo: <br></br>
            </p>

            <div className="activities_wrapper">
              <ActivityCard 
                image={images.temple}
                title="Visit a Traditional Temple"
                description="Explore ancient temples like Senso-ji and experience Japanese spirituality."
                price="25,95$"
                whenAddToCart={() =>
                  AddToCart({
                    id: "temple",
                    name: "Traditional Temple",
                    price: 25.95,
                  })
                }
              />
              <ActivityCard 
                image={images.tea_ceremony}
                title="Attend a Tea Ceremony"
                description="Take part in a traditional tea ceremony guided by experienced hosts."
                price="64,65$"
                whenAddToCart={() =>
                  AddToCart({
                    id: "tea",
                    name: "Tea Ceremony",
                    price: 64.65,
                  })
                }
              />
              <ActivityCard 
                image={images.samurai_museum}
                title="Visit the Japanese History Museum"
                description="Discover the history of Japan through art, objects and exhibitions."
                price="14,49$"
                whenAddToCart={() =>
                  AddToCart({
                    id: "museum",
                    name: "History Museum",
                    price: 14.49,
                  })
                }
              />
            </div>
          </div>
        )}
        {/* Gastronomy section */}
        {activeCategory === "Gastronomy" && (
          <div>
            <h2>Gastronomy in Tokyo</h2>
            <hr></hr>
            <p>
              Tokyo is one of the world's most exciting dining destinations. 
              The city features a wide range of both local and regional Japanese cuisine in addition to all types of international fare. <br></br>
              <b>Its top restaurants have obtained more Michelin stars than both Paris and New York combined.</b> But good food can be found at every price range from cheap 
              hole-in-the-wall joints to expensive high-class restaurants with every budget in between. <br></br>
              Some of the most famous Tokyo specialities are <b>Nigiri-zushi, Soba, Monjayaki</b> and so on. <br></br>
              <br></br>
            </p>

            <video src={videos.gastro_video} 
              className="gastro_video"
              autoPlay
              loop
              muted
              playsInline
            />
            <figcaption className = "caption_video">
              A short promotional video made with Blender presenting Tokyo's gastronomy and food culture.
            </figcaption>

            <p> Here are some recommended gastronomic activities and experiences to enjoy the rich food culture of Tokyo: </p>

            <div className="activities_wrapper">
              <ActivityCard 
                image={images.fish_market}
                title="Tsukiji Fish Market and Walking Tour"
                description="A walking tour to explore fresh seafood and local food culture at Tsukiji Fish Market."
                price="43,99$"
                whenAddToCart={() =>
                  AddToCart({
                    id: "fish_market",
                    name: "Tsukiji Fish Market",
                    price: 43.99,
                  })
                }
              />
              <ActivityCard 
                image={images.ramen}
                title="Ramen and Sushi Cooking Class"
                description="A hands-on cooking class to learn how to prepare traditional ramen and sushi."
                price="68,48$"
                whenAddToCart={() =>
                  AddToCart({
                    id: "cooking_class",
                    name: "Cooking Class",
                    price: 68.48,
                  })
                }
              />
              <ActivityCard 
                image={images.shinjuku}
                title="Shinjuku Food Tour"
                description="A guided food tour to discover local dishes and street food in Shinjuku."
                price="90,50$"
                whenAddToCart={() =>
                  AddToCart({
                    id: "shinjuku",
                    name: "Shinjuku Food Tour",
                    price: 90.5,
                  })
                }
              />
            </div>
          </div>
        )}
        {/* Nature section */}
        {activeCategory === "Nature" && (
          <div>
            <h2>Nature in Tokyo</h2>
            <hr></hr>
            <p>
              It may be a metropolis famed for skyscrapers and high-rises, but <b>Tokyo has an amazing variety of outdoor escapes
              and countless parks to choose from.</b> If you want a ramble then these hikes are a great place to start, with lots of hiking groups 
              around if you don't fancy going it alone. For shorter and flatter walking, Tokyo has some good urban walking routes 
              and a few oases of nature within the city limits. <br></br>
              In addition to hiking and walking routes, <b>Tokyo offers many green spaces</b> where visitors can relax and enjoy nature away from the busy streets. 
              Parks such as traditional Japanese gardens provide peaceful environments that contrast with the fast-paced city life. <br></br>
              These outdoor areas allow both locals and tourists to experience <b>a different side of Tokyo</b>, combining modern urban living with moments of calm and natural beauty throughout the city.
              A perfect example is the Hamarikyu Garden.
            </p>

            <img src={images.hamarikyu} alt="Hamarikyu Garden" className = "nature_photo"/>
            <figcaption className = "caption_photo">
              Edited photo with GIMP (color correction, cropping and adding text behind the buildings) of the Hamarikyu Garden
            </figcaption>

            <div className="activities_wrapper">
              <ActivityCard 
                image={images.fuji}
                title="Mount Fuji Full Day Hiking Tour"
                description="A full-day guided hiking tour to experience Mount Fuji's natural landscapes."
                price="51,05$"
                whenAddToCart={() =>
                  AddToCart({
                    id: "mt_fuji",
                    name: "Mount Fuji Hiking Tour",
                    price: 51.05,
                  })
                }
              />
              <ActivityCard 
                image={images.palace_gardens}
                title="Palace Gardens Tour"
                description="A guided tour through the Imperial Palace Gardens to explore historical landmarks."
                price="25,50$"
                whenAddToCart={() =>
                  AddToCart({
                    id: "imperial_palace",
                    name: "Imperial Palace Gardens Tour",
                    price: 25.50,
                  })
                }
              />              
              <ActivityCard 
                image={images.lake_ashi}
                title="Lake Ashi Cruise"
                description="A scenic boat cruise on Lake Ashi offering beautiful views of nature."
                price="17,45$"
                whenAddToCart={() =>
                  AddToCart({
                    id: "lake_ashi",
                    name: "Lake Ashi Cruise",
                    price: 17.45,
                  })
                }
              />
            </div>
          </div>
        )}
        {/* Urban Life section */}
        {activeCategory === "UrbanLife" && (
          <div>
            <h2>Urban Life in Tokyo</h2>
            <hr></hr>
            <p>
              Urban life in Tokyo is <b>vibrant and dynamic</b>, with a unique blend of traditional culture and modern innovation. 
              The city offers a wide range of experiences, from bustling shopping districts to serene temples and parks. Tokyo's urban lifestyle <b>is characterized by its efficiency, 
              cleanliness, and the constant energy of its people.</b> <br></br>
              <br></br>
              <br></br>
              Here is a further explanation of Tokyo's urban life:
            </p>
            <AudioGesture className="audio"/>
            
            <br></br>
            <br></br>

            <div className="activities_wrapper">
              <ActivityCard 
                image={images.shibuya}
                title="Shibuya Local Bars Tour"
                description="A guided evening tour exploring local bars in Shibuya."
                price="27,85$"
                whenAddToCart={() =>
                  AddToCart({
                    id: "shibuya_bars",
                    name: "Shibuya Local Bars Tour",
                    price: 27.85,
                  })
                }
              />
              <ActivityCard 
                image={images.Akihabara}
                title="Akihabara Night Tour"
                description="A guided walk through Akihabara to explore neon lights, gaming culture and modern Japanese technology."
                price="14,49$"
                whenAddToCart={() =>
                  AddToCart({
                    id: "akihabara_tour",
                    name: "Akihabara Night Tour",
                    price: 14.49,
                  })
                }
              />
              <ActivityCard 
                image={images.street_photo}
                title="Tokyo Street Photography Tour"
                description="A guided photography tour through Tokyo's streets to capture everyday urban life and iconic city scenes."
                price="44,45$"
                whenAddToCart={() =>
                  AddToCart({
                    id: "street_photo_tour",
                    name: "Street Photography tour",
                    price: 44.45,
                  })
                }
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default Web;