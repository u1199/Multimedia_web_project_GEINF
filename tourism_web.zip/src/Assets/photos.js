//Import the activity cards photos and videos here to make it simpler in the TourismWeb.js
import temple from "./photos/temple_photo.jpg";
import tea_ceremony from "./photos/tea_ceremony.jpg";
import samurai_museum from "./photos/samurai_museum.jpg";
import fish_market from "./photos/fish_market.jpg";
import ramen from "./photos/ramen.jpg";
import shinjuku from "./photos/Shinjuku.jpg";
import gastro_video from "./photos/gastronomy_video.mp4";
import hamarikyu from "./photos/hamarikyu_garden.jpg";
import fuji from "./photos/fuji.jpg";
import palace_gardens from "./photos/imperial_palace.jpg"
import lake_ashi from "./photos/lake_ashi.jpg"
import shibuya from "./photos/shibuya.jpg"
import Akihabara from "./photos/Akihabara.jpg"
import street_photo from "./photos/street_photo.jpg"

export const images = {
    temple,
    tea_ceremony,
    samurai_museum,
    fish_market,
    ramen,
    shinjuku,
    hamarikyu,
    fuji,
    palace_gardens,
    lake_ashi,
    shibuya,
    Akihabara,
    street_photo
};

export const videos = {
    gastro_video
};
