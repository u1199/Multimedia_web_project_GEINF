// ActivityCard component to simplify the TourismWeb file
export default function ActivityCard({ image, title, description, price, whenAddToCart }) {
    return (
        <div className="activity_card">
            <img src={image}/>
            <div className="activity_text">
                <h3>{title}</h3>
                <p>{description}</p>
            </div>
        <div className="card_left">
            <p>{price}</p>
            <button onClick={whenAddToCart}>Add to cart</button>
        </div>
    </div>
    );
}