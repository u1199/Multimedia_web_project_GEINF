//File to handle the animation and audio reporoduction
import { motion } from "motion/react";
import { useRef, useState } from "react";
import urban_life_audio from "../Assets/urban_audio_speech.mp3";

export default function AudioGesture() {
  /*Modify the extension to make it reproduce audio*/
  const audioRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const changeAudio = () => {
    if (!audioRef.current) return;

    if (audioRef.current.paused) {
      audioRef.current.play();
      setIsPlaying(true);
    } else {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  };

  return (
    <>
      <motion.div
        className="audio"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={changeAudio}
        style={box}
      >
        ▶
      </motion.div>

      <audio ref={audioRef} src={urban_life_audio} />
    </>
  );
}

const box = {
  width: 60,
  height: 60,
  backgroundColor: "rgba(126, 39, 39, 1)",
  borderRadius: "50%",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  color: "#fff",
  fontSize: "24px",
  cursor: "pointer",
};
